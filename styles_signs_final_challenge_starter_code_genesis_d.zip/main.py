import pandas as pd
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import  confusion_matrix, classification_report
from sklearn.model_selection import train_test_split
from collections import defaultdict
import matplotlib.pyplot as plt
import numpy as np

# Load the training dataset
print("I have created a computer model that can recongize American sign language. Below are the results, as well with the training data size.")
print(" ")
train_data = pd.read_csv('sign_mnist_13bal_train.csv')
"""selected_labels = [0, 1, 2, 3, 8]
sLabels = train_data['class'].isin(selected_labels)
train_data = train_data[sLabels]
"""
# Separate the data (features) and the  classes
X_train = train_data.drop('class', axis=1)  # Features (all columns except the first one)
X_train = X_train / 255.0
y_train = train_data['class']   # Target (first column)

# Load the testing dataset
test_data = pd.read_csv('sign_mnist_13bal_test.csv')
"""s_labels = test_data['class'].isin(selected_labels)
test_data = test_data[s_labels]
"""
# Separate the data (features) and the  classes
X_test = test_data.drop('class', axis=1)  # Features (all columns except the first one)
X_test = X_test / 255.0
y_test = test_data['class']   # Target (first column)

# Use this line to get you started on adding a validation dataset
X_train, X_test, y_train, y_test = train_test_split(X_train, y_train, test_size=10, random_state=0)

neural_net_model = MLPClassifier( hidden_layer_sizes=(12),random_state=42,tol=0.005)

neural_net_model.fit(X_train, y_train)
# Determine model architecture 
layer_sizes = [neural_net_model.coefs_[0].shape[0]]  # Start with the input layer size
layer_sizes += [coef.shape[1] for coef in neural_net_model.coefs_]  # Add sizes of subsequent layers
layer_size_str = " x ".join(map(str, layer_sizes))
print(f"Training set size: {len(y_train)}")
print(f"Layer sizes: {layer_size_str}")


# predict the classes from the training and test sets
y_pred_train = neural_net_model.predict(X_train)
y_pred = neural_net_model.predict(X_test)

# Create dictionaries to hold total and correct counts for each class
correct_counts = defaultdict(int)
total_counts = defaultdict(int)
overall_correct = 0

# Count correct test predictions for each class
for true, pred in zip(y_test, y_pred):
    total_counts[true] += 1
    if true == pred:
        correct_counts[true] += 1
        overall_correct += 1

# For comparison, count correct _training_ set predictions
total_counts_training = 0
correct_counts_training = 0
for true, pred in zip(y_train, y_pred_train):
    total_counts_training += 1
    if true == pred:
        correct_counts_training += 1


# Calculate and print accuracy for each class and overall test accuracy
for class_id in sorted(total_counts.keys()):
    accuracy = correct_counts[class_id] / total_counts[class_id] *100
    print(f"Accuracy for class {class_id}: {accuracy:3.0f}%")
print(f"----------")
overall_accuracy = overall_correct / len(y_test)*100
print(f"Overall Test Accuracy: {overall_accuracy:3.1f}%")
overall_training_accuracy = correct_counts_training / total_counts_training*100
print(f"Overall Training Accuracy: {overall_training_accuracy:3.1f}%")
print("")
input("Please press enter to continue.\n")
print("This is the confusion matrix, this indicates where the model miss categorized a gesture.")
print(" ")
conf_matrix = confusion_matrix(y_test, y_pred)
class_ids = sorted(total_counts.keys())

# For better formatting
print("Confusion Matrix:")
print(f"{'':9s}", end='')
for label in class_ids:
    print(f"Class {label:2d} ", end='')
print()
for i, row in enumerate(conf_matrix):
    print(f"Class {class_ids[i]}:", " ".join(f"{num:7d}" for num in row))
print(" ")
input("Please press enter to continue.\n")
class_number = 1 # Class to display

# FILTER DATA
# Select first 20 rows matching class number
class_0_test_data = test_data[test_data['class'] == class_number].head(10)

# DISPLAY IMAGES
# Set up 4x5 grid of subplots
fig, axes = plt.subplots(nrows=2, ncols=5, figsize=(10, 8))

for i, row in enumerate(class_0_test_data.iterrows()):

    # Strip label, leaving only pixel values
    image_data = row[1][1:].values

    # Convert to unsigned integer for image display
    image_data = image_data.astype(np.uint8)

    # Reshape pixel values into 28x28 grid
    image_28x28 = image_data.reshape(28, 28)

    # Plot image in correct grid position
    ax = axes[i // 5, i % 5]
    ax.imshow(image_28x28, cmap='gray')
    ax.axis('off')

plt.tight_layout()
plt.show()
print("Here, the image shows that the model gets confused with the symbol for B. But its not only that but the symbols for E and F too. To view those images please change class_number to either 4 or 5. This is most likely because these hand symbols are too similar to other ones in the data and make it difficult for the computer model to tell them apart.")
print(" ")
print("Thank you for reading through my computer model on american sign language.")