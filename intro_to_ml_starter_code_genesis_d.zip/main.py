import pandas as pd
import GWCutilities as util

pd.set_option('display.max_columns', None)
pd.set_option('max_colwidth', None)

print("\n-----\n")

#Create a variable to read the dataset
df = pd.read_csv("heartDisease_2020_sampling.csv")

print(
    "We will be performing data analysis on this Indicators of Heart Disease Dataset. Here is a sample of it: \n"
)

#Print the dataset's first five rows
print(df.head)

input("\n Press Enter to continue.\n")



#Data Cleaning
#Label encode the dataset
df = util.labelEncoder(df, ["HeartDisease", "GenHealth", "Smoking", "AlcoholDrinking", "Sex", "PhysicalActivity", "AgeCategory"])
print(df.head())
print("\nHere is a preview of the dataset after label encoding. \n")

input("\nPress Enter to continue.\n")

#One hot encode the dataset
df =util.oneHotEncoder(df, ["Race"])
print(df.head())

print(
    "\nHere is a preview of the dataset after one hot encoding. This will be the dataset used for data analysis: \n"
)


input("\nPress Enter to continue.\n")



#Creates and trains Decision Tree Model
from sklearn.model_selection import train_test_split
X = df.drop("HeartDisease", axis = 1)
y = df["HeartDisease"]
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state = 8)

print(X_train.head())
from sklearn.tree import DecisionTreeClassifier
clf = DecisionTreeClassifier(max_depth = 7,class_weight = 'balanced')
clf = clf.fit(X_train, y_train)

#Test the model with the testing data set and prints accuracy score
test_predictions = clf.predict(X_test)
from sklearn.metrics import accuracy_score
test_acc = accuracy_score(y_test, test_predictions)

print("The accuracy score of with testing data of the Decision Tree is "+ str(test_acc))



#Prints the confusion matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, test_predictions, labels = [1, 0])
print("The confusion matrix for this tree is ")
print(cm)


#Test the model with the training data set and prints accuracy score
train_predictions = clf.predict(X_train)
from sklearn.metrics import accuracy_score
train_acc = accuracy_score(y_train, train_predictions)

print("The accuracy score of with training data of the Decision Tree is "+ str(train_acc))



input("\nPress Enter to continue.\n")



#Prints another application of Decision Trees and considerations
print("\nBelow is another application of decision trees and considerations for using them:\n")
print("This decision tree can be used in a variety of different fields. Lets take recommendations, which in all likelihood already involve decision trees in the form of an algorithm. Book recommendations to be specific. My favorite genre is romance fantasty. While a decision tree wouldn't know that, I could feed it the data of other books I've read and how much I enjoyed it. Then based on that information I can give it new data on books I haven't read and then it could recommend me some. Thats only one very simple way though.")
print(" ")
print("Althought with their usefullness, there are a few things to be weary of. Such as class bias. When first creating this decision tree the data provided had more people without heart disease, so the model learned by classifing very few people with it or no people at all it would still be highly accurate. So there needed to be more weight in the class of people with heart disease. Not only that, but the model might focus heavily on the training data that it will mess up more with the test data which is argueably more important. To phrase it this way: It focused more on the practice problems than the actual test, so when the test came it panicked at the new questions even though they were very similar to the ones it had been studying. So when it focused on the training data too much, it was just memorizing it, not how it acctually works. This is why the max depth of model had to be 7 because if not it focuses too much on the training.")
print(" ")


#Prints a text representation of the Decision Tree
print("\nBelow is a text representation of how the Decision Tree makes choices:\n")
input("\nPress Enter to continue.\n")
util.printTree(clf, X.columns)

