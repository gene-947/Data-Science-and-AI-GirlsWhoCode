# This code is written in python
# The pandas library is used for data processing and to read data files
import pandas as pd 
#The matplotlib library is used to plot histograms and scatter plots
import matplotlib.pyplot as plt
# The GWCutilities has functions to help format data printed to the console
import GWCutilities as util

# Read a comma separated values (CSV) files into a variable
# as a pandas DataFrame
#Btw, the stories I share here are fake. I've made them up because they are indeed still possible, they are one of the many stories the data can tell.
lwd=pd.read_csv("livwell175.csv")
print(" ")
print ("In many places around the world, not just in one singular country there have been inevitable cases of both domestic violence and infant mortalitly. Today, I'll present you with data of both of these things happening in the countries Jordan and Peru. They are on different sides of the world and on different continents.")
print(" ")
print("I asked why does domestic violence and infant mortality in Peru and Jordan have a positive corlation? This is my response.") 
print(" ")
input("Please press enter/return to continue.\n")
print("I had a friend once. Her name was Mariana, she lived in Peru. She maried a guy she was dating for a year, at the day of their wedding they seemed like the happest couple alive. They had these cheerful similes, so blindingly bright, that I coudln't help but simile in return despite the cheeply made clothes they were wearing and the worn down venue. Mariana told me about the amazing honeymoon she had even though it was hardly what I would consider a honeymoon. We used to call everyday. A month after the wedding though she started calling me less. I didn't know why, I probably should've asked her about it. But I thought she was so madly inlove that I became of less importance to her.")
print("On one of our calls she exclaimed to me 'Im pregnant!' Her voice was enthusastic, but... There was something about her voice that was underlying, and her face although it was happy looked tired. I asked her,")
print("'Are you okay?'")
print(" ")
input("Please press enter/return to continue.\n")
print("'...N-no.' Her voice cracked, and for a second I heard something. I hear fear. Something like that was so unlike her it broke my heart, even if it was only there for a second. After she said no she told me about the horrible things her husband did to her. How he hit her. Punished her. Over the simplest of things, like not doing the dishes, even though its supposed to be their shared responsiblity. When she was done telling me her abuse, I talked to her husband and helped her out of it. They didn't divorce for some reason, I would've perfered it that way.")
print(" ")
input("Please press enter/return to continue.\n")
print("Months later, after her baby was born. She sent me the image of her skin to skin with her baby. Mariana had this shine in her eyes, it was proud, loving, and joyful. That was the happiest I've ever seen Mariana. That was until a day later, her baby died. She was devastated. I felt so sorry for her.")
print(" ")
input("Please press enter/return to continue.\n")
print("This is the reality of many women in Peru.")
print(" ")
peruList = lwd["country_name"] == "Peru"
peru = lwd.loc[peruList]
plt.scatter(y = "HL_IMR", x = "DV_phys_partner_p", data = peru, c = "green")
plt.ylim(0,45)
plt.xlim(1, 45)
plt.ylabel("Infant Mortality Rate %")
plt.xlabel("Women who have experienced physical domestic violence by partner %")
plt.show()
print("This graph shows how in Peru, many women who have experienced physical domestic violence by their PARTNER have had increased infant morality rates. This is a system failure to these women. Not only could the authorites in their country not prevent them from being physically abused but their precious newly born dies. The hospital didn't tell her why, but Peru already had a bad healthcare system so Mariana wasn't going to find out.")
print(" ")
input("Please press enter/return to continue.\n")
print("In Jordan the story can be very similar to Mariana's. Its not as bad though because Jordan has one of the best health care systems in the middle east and they experience less poverty than peru. That doesn't make the story any less plausible, and any less important.") 
print(" ")
input("Please press enter/return to continue.\n")
print("In Jordan, as the graph shows, its considerably less on both domestic violence and infant mortality. It could be because of the two factors I mentioned, or something else entirely. But the story of Mariana and many women in both Peru and Jordan lies on that graph.")
print(" ")
jordanList = lwd["country_name"] == "Jordan"
jordan = lwd.loc[jordanList]
plt.scatter(y = "HL_IMR", x = "DV_phys_partner_p", data = jordan, c = "blueviolet")
plt.ylim(0,45)
plt.xlim(1, 45)
plt.show()
input("Please press enter/return to continue.\n")
print(" This is percisely why I want your help, I've told you the story, I've told you the data, I've told you the question, this is a real issue. This is where you come in. You can help many women in not just Peru and Jordan but across the world, because this is a trend, a pattern. Something like this doesn't happen by coincidence. Step up, and help me make the world a better place for these women... And the lives of their possible children. You can help me prevent domestic violence and help the healthcare for the poor or promote healthcare to protect infants.")
print("")
print("Please reach out to me with your response, and thank you for your time. Have a good day.")