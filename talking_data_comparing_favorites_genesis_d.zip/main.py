#Talking Data Starter Code

#Part 2 Setting up the program
import pandas as pd
import matplotlib.pyplot as plt

pd.set_option('display.max_columns', None)
pd.set_option('max_colwidth', None)

movieData = pd.read_csv('./rotten_tomatoes_movies.csv')
favMovie = "To All the Boys I've Loved Before"

print("This is my favorite movie "+favMovie+".")

#Part 3 Investigate the data
#print(movieData.head())
#print(movieData["movie_title"]

#Part 4 Filter data
print("\nThe data for my favorite movie is:\n")
#Create a new variable to store your favorite movie information
favMovieBoolean = movieData["movie_title"] == favMovie
favMovieData = movieData.loc[favMovieBoolean]
print(favMovieData)

print("\n\n")

#Create a new variable to store a new data set with a certain genre
romanceGenre = movieData["genres"].str.contains("Romance")
romanceMovieData = movieData.loc[romanceGenre]

numOfMovies = romanceGenre.shape[0]

print("We will be comparing " + favMovie +
      " to other movies under the genre Romance in the data set.\n")
print("There are " + str(numOfMovies) + " movies under the category Romance.")

print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
input("Press enter to see more information about how " + favMovie +
      " compares to other movies in this genre.\n")

#Part 5 Describe data
#min
min = romanceMovieData["audience_rating"].min()
print("The min audience rating of the data set is: " + str(min))
print(favMovie + " is rated 77 points higher than the lowest rated movie.")
print()

#find max
max = romanceMovieData["audience_rating"].max()
print("The max audience rating of the data set is: " + str(max))
print(favMovie + " is rated 14 points lower than the highest rated movie.")
print()

#find mean
mean = romanceMovieData["audience_rating"].mean()
print("The mean audience rating of the data set is: " + str(mean))
print(favMovie, "is higher than the mean movie rating.")

#find median
median = romanceMovieData["audience_rating"].median()
print("The median audience rating of the data set is: " + str(median))
print(favMovie + " is higher than the median movie rating.")

print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
input("Press enter to see data visualizations.\n")

#Part 6 Create graphs
#Create histogram
plt.hist(romanceMovieData["audience_rating"], range = (0,100), bins = 100)

#Adds labels and adjusts histogram
plt.grid(True)
plt.title("Romance Audience Movie Ratings")
plt.xlabel("Audience Ratings")
plt.ylabel("# of romance movies")

#Prints interpretation of histogram
print(
  "According to the histogram, most romance movies audience ratings fall into the range of 70 - 80 percent. I find it very interesting how certain percentages closer to the mean and median's value which is around 63-66% have less movies rated in those catagories."
)
print()

#Show histogram
plt.show()
plt.close()
input("Press enter to see the next data visualization.\n")


#Create scatterplot
plt.scatter(data = romanceMovieData, x = "audience_rating", y = "critic_rating")
label = "Romance Movies"
#Adds labels and adjusts scatterplot
x = "audience_rating"
y = "critic_rating"
plt.scatter(favMovie, x, y)
label = favMovie
plt.legend("purple")
plt.grid(True)
plt.title("Audience and Critic Ratings of Romance Movies")
plt.xlabel("Audience Ratings")
plt.ylabel("Critic Ratings")
plt.xlim(0, 100)
plt.ylim(0, 100)
#Prints interpretation of scatterplot
print("The purple plot point is my favorite movie, "+favMovie+". It is in the cluster at the top of the scatterplot.")
print(
  "According to the scatter plot, there are a few outliers. Such as the movie rated about 90% for the audien but a measly 10% by critics. Or this other movie rated about 82% by critcs but only about 22% by the audience. There is a postive corrlation despite this, with both the audience and critics seeming to appreciate romance movies the same"
)
print()


#Show scatterplot
plt.show()

print("\nThank you for reading through my data analysis!")
